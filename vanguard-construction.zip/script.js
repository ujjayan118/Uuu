
console.log("Vanguard Construction site loaded.");
